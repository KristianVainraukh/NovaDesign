import React from 'react';
import { Mail, Phone, ArrowRight } from 'lucide-react';

function Contact() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&q=80"
            alt="Modern Office Interior"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <h1 className="text-4xl md:text-7xl font-light mb-4 md:mb-6">Get in Touch</h1>
          <p className="text-base md:text-xl text-gray-300 max-w-2xl">
            Let's discuss your vision and create something extraordinary together. 
            Our team is ready to bring your architectural dreams to life.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="space-y-8 md:space-y-12">
            <div className="flex items-start space-x-4">
              <Mail className="h-6 w-6 text-gray-400 mt-1" />
              <div>
                <h3 className="font-medium mb-1">Email</h3>
                <a 
                  href="mailto:Novadesignnarch@gmail.com"
                  className="text-gray-600 hover:text-black transition-colors"
                >
                  Novadesignnarch@gmail.com
                </a>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <Phone className="h-6 w-6 text-gray-400 mt-1" />
              <div>
                <h3 className="font-medium mb-1">Phone</h3>
                <p className="text-gray-600">(610)-579-0997</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-12 md:mb-16 text-center">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {[
              {
                question: "What is your typical project timeline?",
                answer: "Project timelines vary depending on scope and complexity."
              },
              {
                question: "Do you work on projects outside of Pennsylvania?",
                answer: "Yes! While we're based in Philadelphia, we work with clients worldwide for architectural visualization projects. For our design services, we primarily serve the Northeast region of the United States."
              },
              {
                question: "What is your design process?",
                answer: "Our process begins with an initial consultation, followed by concept development, detailed design, and implementation phases. We maintain close communication throughout."
              },
              {
                question: "How do you handle project budgets?",
                answer: "We work closely with clients to establish realistic budgets early in the process and provide regular updates to ensure transparency and cost control."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-white p-6 md:p-8 rounded-lg shadow-sm">
                <h3 className="text-lg md:text-xl font-medium mb-3 md:mb-4">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;
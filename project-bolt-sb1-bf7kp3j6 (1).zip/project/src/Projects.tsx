import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const projects = [
  {
    title: "Zen Minimalist Kitchen",
    year: "2024",
    description: "A serene kitchen space that embodies modern minimalism. Clean lines and natural materials create a harmonious environment for cooking and gathering.",
    image: "https://i.postimg.cc/XvXwh1wh/IMG-5999.jpg",
    location: "Bryn Mawr, PA",
    details: {
      features: [
        "Custom Cabinetry",
        "Modern Appliances",
        "Natural Materials",
        "Ambient Lighting"
      ]
    }
  },
  {
    title: "Bright & Timeless",
    year: "2024",
    description: "A luminous kitchen design that combines classic elements with contemporary touches. Thoughtful lighting and bright finishes create an inviting, timeless space.",
    image: "https://i.postimg.cc/rwjSS7fp/Untitled-11-1.jpg",
    location: "Philadelphia, PA",
    details: {
      features: [
        "Natural Lighting",
        "White Cabinetry",
        "Elegant Hardware",
        "Timeless Design"
      ]
    }
  }
];

function Projects() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-24 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80"
            alt="Architectural Design"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <h1 className="text-5xl md:text-7xl font-light mb-6">Design Portfolio</h1>
          <p className="text-xl text-gray-300 max-w-2xl">
            Discover our transformative approach to space design where innovation meets functionality. 
            Our commitment to creating environments that inspire and endure is exemplified in our featured projects.
          </p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          {projects.map((project, index) => (
            <div key={index} className={`grid md:grid-cols-2 gap-12 items-center ${
              index !== 0 ? 'mt-32' : ''
            }`}>
              <div className={`image-3d-container ${index % 2 === 1 ? 'md:order-2' : ''}`}>
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-[500px] object-cover rounded-lg shadow-2xl image-3d"
                />
              </div>
              <div className={index % 2 === 1 ? 'md:order-1' : ''}>
                <span className="text-sm text-gray-500">{project.year}</span>
                <h2 className="text-4xl font-light mt-2 mb-4">{project.title}</h2>
                <p className="text-gray-600 mb-6">{project.description}</p>
                <div className="grid grid-cols-2 gap-4 mb-8">
                  {project.details.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <div className="w-1 h-1 bg-black rounded-full"></div>
                      <span className="text-sm text-gray-600">{feature}</span>
                    </div>
                  ))}
                </div>
                <Link 
                  to={index === 0 ? "/projects/modern-kitchen" : "/projects/bright-timeless"}
                  className="float-on-hover bg-black text-white px-8 py-4 rounded-full hover:bg-gray-800 transition flex items-center space-x-2 w-fit"
                >
                  <span>View Project Details</span>
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-light mb-6">Ready to Transform Your Space?</h2>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Let's create your dream space together. Our team specializes in modern, 
            functional designs that inspire and delight.
          </p>
          <Link 
            to="/contact"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-8 py-4 rounded-full hover:bg-gray-100 transition"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Projects;
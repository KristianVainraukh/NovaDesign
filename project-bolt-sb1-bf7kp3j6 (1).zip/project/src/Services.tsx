import React from 'react';
import { Square, Compass, Users, Ruler, PenTool, Building2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: <div className="relative w-8 h-8">
      <Square className="h-4 w-4 absolute top-0 left-0 stroke-[1.5]" />
      <Square className="h-4 w-4 absolute top-0 right-0 stroke-[1.5]" />
      <Square className="h-4 w-4 absolute bottom-0 left-0 fill-current stroke-[1.5]" />
      <Square className="h-4 w-4 absolute bottom-0 right-0 stroke-[1.5]" />
    </div>,
    title: "Visual Architecture",
    description: "Transforming ideas into stunning visual realities. We create immersive architectural experiences that blend aesthetics with functionality, focusing on innovative design solutions.",
    features: ["3D Visualization", "Concept Development", "Design Innovation", "Spatial Planning"],
    link: "/services/visual-architecture"
  },
  {
    icon: <Compass className="h-8 w-8" />,
    title: "Interior Planning",
    description: "Transforming spaces with thoughtful interior design that reflects your unique style and needs. We create harmonious environments that enhance both form and function.",
    features: ["Space Planning", "Material Selection", "Lighting Design", "Custom Furniture"],
    link: "/services/interior-planning"
  },
  {
    icon: <Users className="h-8 w-8" />,
    title: "Project Management",
    description: "Working alongside our trusted contractor network to transform concepts into reality. Our experienced team ensures your project stays on track and exceeds expectations.",
    features: ["Timeline Management", "Budget Control", "Contractor Coordination", "Quality Assurance"],
    link: "/services/project-management"
  }
];

function Services() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80"
            alt="Interior Design"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <h1 className="text-4xl md:text-7xl font-light mb-4 md:mb-6">Our Services</h1>
          <p className="text-base md:text-xl text-gray-300 max-w-2xl">
            Comprehensive design solutions tailored to your vision. We combine creativity 
            and expertise to deliver exceptional spaces that inspire.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Link 
                key={index}
                to={service.link || '#'}
                className={`expertise-card bg-white p-6 md:p-8 rounded-lg shadow-sm hover:shadow-xl transition-all duration-300 ${!service.link && 'cursor-default'}`}
                onClick={e => !service.link && e.preventDefault()}
              >
                <div className="mb-4 md:mb-6 text-gray-800">{service.icon}</div>
                <h3 className="text-xl md:text-2xl font-light mb-3 md:mb-4">{service.title}</h3>
                <p className="text-sm md:text-base text-gray-600 mb-4 md:mb-6">{service.description}</p>
                <ul className="space-y-2 md:space-y-3">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm md:text-base text-gray-700">
                      <ArrowRight className="h-3 w-3 md:h-4 md:w-4 mr-2 text-gray-400 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-light mb-4 md:mb-6">Ready to Start Your Project?</h2>
          <p className="text-base md:text-xl text-gray-400 mb-6 md:mb-8 max-w-2xl mx-auto">
            Let's discuss how we can bring your design vision to life. Our team is ready 
            to help you create something extraordinary.
          </p>
          <a 
            href="mailto:Novadesignnarch@gmail.com"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-6 md:px-8 py-3 md:py-4 rounded-full hover:bg-gray-100 transition text-sm md:text-base"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
          </a>
        </div>
      </section>
    </div>
  );
}

export default Services;
import React from 'react';
import { ArrowLeft, ArrowRight, Check, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';

const pricingPlans = [
  {
    name: "Basic Visualization",
    price: "2,500",
    description: "Perfect for small residential projects and single-room visualizations",
    features: [
      "2 Design Concepts",
      "3 Revision Rounds",
      "High-Quality Still Renders",
      "Basic Material Selection",
      "Standard Lighting Setup",
      "Digital Delivery"
    ]
  },
  {
    name: "Professional",
    price: "5,000",
    description: "Ideal for complete home renovations and medium-sized projects",
    features: [
      "4 Design Concepts",
      "5 Revision Rounds",
      "High-Quality Still Renders",
      "360° Virtual Tour",
      "Advanced Material Selection",
      "Custom Lighting Design",
      "Project Consultation",
      "Priority Support"
    ],
    popular: true
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "Tailored for commercial projects and large-scale developments",
    features: [
      "Unlimited Design Concepts",
      "Unlimited Revisions",
      "4K Ultra HD Renders",
      "Interactive Virtual Tour",
      "Complete Material Library",
      "Advanced Lighting Simulation",
      "Dedicated Project Manager",
      "24/7 Priority Support",
      "Marketing Materials"
    ]
  }
];

function Pricing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80"
            alt="Architectural Visualization"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <Link 
            to="/services/visual-architecture"
            className="inline-flex items-center space-x-2 text-white hover:text-gray-200 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4 md:h-5 md:w-5" />
            <span>Back to Visual Architecture</span>
          </Link>
          <h1 className="text-4xl md:text-7xl font-light mb-6">Pricing Plans</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl">
            Transparent pricing options tailored to your project needs. Choose the plan 
            that best fits your vision and budget.
          </p>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div 
                key={index}
                className={`relative bg-white p-8 rounded-lg shadow-sm hover:shadow-xl transition-shadow ${
                  plan.popular ? 'ring-2 ring-black' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-black text-white px-4 py-1 rounded-full text-sm">
                    Most Popular
                  </div>
                )}
                <div className="mb-8">
                  <h3 className="text-2xl font-medium mb-2">{plan.name}</h3>
                  <div className="flex items-baseline mb-4">
                    <DollarSign className="h-6 w-6 text-gray-400" />
                    <span className="text-4xl font-light">{plan.price}</span>
                  </div>
                  <p className="text-gray-600">{plan.description}</p>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-3">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/contact"
                  className="float-on-hover block text-center bg-black text-white px-6 py-3 rounded-full hover:bg-gray-800 transition"
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-16 text-center">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                question: "What's included in each visualization?",
                answer: "Each visualization includes high-quality renders from multiple angles, material specifications, and lighting setups. The number of views and revisions varies by plan."
              },
              {
                question: "How long does the process take?",
                answer: "Time varies based on scope."
              },
              {
                question: "Can I customize a package?",
                answer: "Yes! We can create custom packages tailored to your specific project needs. Contact us to discuss your requirements."
              },
              {
                question: "What format will I receive the files in?",
                answer: "You'll receive high-resolution JPEG/PNG files for still renders, and interactive web-based formats for virtual tours where applicable."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-lg">
                <h3 className="text-xl font-medium mb-4">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-light mb-6">Ready to Start Your Project?</h2>
          <p className="text-lg md:text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Let's discuss your visualization needs and find the perfect package for your project.
          </p>
          <Link 
            to="/contact"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-8 py-4 rounded-full hover:bg-gray-100 transition"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Pricing;
import React, { useState } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import ImageModal from './components/ImageModal';

const features = [
  {
    title: "Custom Cabinetry",
    description: "Handcrafted maple cabinets with soft-close hinges and minimalist hardware, providing ample storage while maintaining clean lines."
  },
  {
    title: "Pendant Lighting",
    description: "Modern glass pendant lights create both ambient illumination and striking visual elements above the island."
  },
  {
    title: "Breakfast Bar",
    description: "Extended quartz countertop creates a comfortable seating area, perfect for casual dining and social interaction."
  },
  {
    title: "Wood Accents",
    description: "Warm wood tones throughout the space add natural elements and create a welcoming atmosphere."
  }
];

const gallery = [
  {
    image: "https://i.postimg.cc/XvXwh1wh/IMG-5999.jpg",
    description: "Main view of the kitchen showing the island and pendant lights"
  },
  {
    image: "https://i.postimg.cc/SxY9fYkF/IMG-5996.jpg",
    description: "The living area"
  },
  {
    image: "https://i.postimg.cc/zfmgtDGL/IMG-5995.jpg",
    description: "Black pull-down spring faucet, modern and bold"
  },
  {
    image: "https://i.postimg.cc/ncP7mG8G/IMG-5998.jpg",
    description: "Kitchen workspace and storage solutions"
  },
  {
    image: "https://i.postimg.cc/qRT2RBff/IMG-5994.jpg",
    description: "Integrated appliances and modern finishes"
  }
];

function ModernKitchenDesign() {
  const [modalOpen, setModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const openModal = (index: number) => {
    setCurrentImageIndex(index);
    setModalOpen(true);
  };

  const handleNext = () => {
    setCurrentImageIndex((prev) => 
      prev === gallery.length - 1 ? prev : prev + 1
    );
  };

  const handlePrevious = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? prev : prev - 1
    );
  };

  return (
    <div className="min-h-screen bg-white pt-20">
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={gallery[0].image}
            alt="Zen Minimalist Kitchen"
            className="w-full h-full object-cover cursor-pointer"
            onClick={() => openModal(0)}
          />
          <div className="absolute inset-0 bg-black/30" />
        </div>
        <div className="relative h-full max-w-7xl mx-auto px-6 flex flex-col justify-end pb-16 md:pb-24">
          <Link 
            to="/projects"
            className="text-white mb-6 md:mb-8 hover:text-gray-200 transition-colors inline-flex items-center space-x-2 text-sm md:text-base"
          >
            <ArrowLeft className="h-4 w-4 md:h-5 md:w-5" />
            <span>Back to Projects</span>
          </Link>
          <h1 className="text-4xl md:text-7xl font-light text-white mb-3 md:mb-4">
            Zen Minimalist Kitchen
          </h1>
          <p className="text-base md:text-xl text-gray-200 max-w-2xl">
            A minimalist kitchen that combines functionality with elegant design elements
          </p>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-12 md:mb-16">Project Gallery</h2>
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {gallery.map((item, index) => (
              <div 
                key={index} 
                className="group relative aspect-[4/3] overflow-hidden rounded-lg cursor-pointer"
                onClick={() => openModal(index)}
              >
                <img 
                  src={item.image}
                  alt={item.description}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
                    <p className="text-white text-sm md:text-base">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-12 md:mb-16">Key Features</h2>
          <div className="grid md:grid-cols-2 gap-6 md:gap-12">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-6 md:p-8 rounded-lg shadow-sm hover:shadow-md transition">
                <h3 className="text-lg md:text-xl font-medium mb-3 md:mb-4">{feature.title}</h3>
                <p className="text-sm md:text-base text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-light mb-4 md:mb-6">Start Your Kitchen Renovation</h2>
          <p className="text-base md:text-xl text-gray-400 mb-6 md:mb-8 max-w-2xl mx-auto">
            Ready to transform your kitchen? Let's create a space that perfectly suits your lifestyle.
          </p>
          <Link 
            to="/contact"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-6 md:px-8 py-3 md:py-4 rounded-full hover:bg-gray-100 transition text-sm md:text-base"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
          </Link>
        </div>
      </section>

      {/* Image Modal */}
      <ImageModal
        images={gallery}
        currentIndex={currentImageIndex}
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onNext={handleNext}
        onPrevious={handlePrevious}
      />
    </div>
  );
}

export default ModernKitchenDesign;
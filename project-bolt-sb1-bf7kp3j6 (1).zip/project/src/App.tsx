import React, { useEffect, useState, Suspense } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { ChevronDown, PenTool, Users, Instagram, ArrowRight, Square, Menu, X } from 'lucide-react';
import LoadingSpinner from './components/LoadingSpinner';

// Lazy load components
const Services = React.lazy(() => import('./Services'));
const Projects = React.lazy(() => import('./Projects'));
const About = React.lazy(() => import('./About'));
const Contact = React.lazy(() => import('./Contact'));
const ModernKitchenDesign = React.lazy(() => import('./ModernKitchenDesign'));
const BrightTimelessKitchen = React.lazy(() => import('./BrightTimelessKitchen'));
const VisualArchitecture = React.lazy(() => import('./VisualArchitecture'));
const InteriorPlanning = React.lazy(() => import('./InteriorPlanning'));
const ProjectManagement = React.lazy(() => import('./ProjectManagement'));
const Pricing = React.lazy(() => import('./Pricing'));

function HomePage() {
  const [opacity, setOpacity] = useState(1);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      const newOpacity = Math.max(0.3, 1 - (scrollPosition / (windowHeight * 2)));
      setOpacity(newOpacity);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div className="absolute inset-0" style={{ opacity }}>
          <img 
            src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80"
            alt="Modern Architecture"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 h-[calc(100vh-80px)] flex flex-col justify-center">
          <h1 className="text-4xl md:text-7xl font-light text-white mb-6">
            From Concept<br />to Reality
          </h1>
          <p className="text-lg md:text-xl text-gray-200 max-w-2xl mb-8">
            Blending creativity, technology, and sustainability, we design stunning and functional architecture that transforms spaces and inspires the future.
          </p>
          <Link 
            to="/projects"
            className="float-on-hover bg-white text-black px-6 md:px-8 py-3 md:py-4 rounded-full inline-flex items-center space-x-2 hover:bg-gray-100 transition w-fit text-sm md:text-base"
          >
            <span>Explore Our Work</span>
            <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
          </Link>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <ChevronDown className="h-8 w-8 text-white animate-bounce" />
        </div>
      </header>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-12 md:mb-16 text-center">Our Expertise</h2>
          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {[
              {
                icon: <div className="relative w-8 h-8">
                  <Square className="h-4 w-4 absolute top-0 left-0 stroke-[1.5]" />
                  <Square className="h-4 w-4 absolute top-0 right-0 stroke-[1.5]" />
                  <Square className="h-4 w-4 absolute bottom-0 left-0 fill-current stroke-[1.5]" />
                  <Square className="h-4 w-4 absolute bottom-0 right-0 stroke-[1.5]" />
                </div>,
                title: "Visual Architecture",
                description: "Crafting immersive and functional spaces through visionary design"
              },
              {
                icon: <PenTool className="h-8 w-8" />,
                title: "Interior Planning",
                description: "Crafting functional and aesthetically pleasing interior spaces that reflect your vision."
              },
              {
                icon: <Users className="h-8 w-8" />,
                title: "Project Management",
                description: "Working alongside professionals to transform concepts into reality"
              }
            ].map((service, index) => (
              <div 
                key={index} 
                className="expertise-card bg-white p-6 md:p-8 rounded-lg shadow-sm hover:shadow-md transition"
              >
                <div className="mb-4 text-gray-800">{service.icon}</div>
                <h3 className="text-lg md:text-xl font-medium mb-3 md:mb-4">{service.title}</h3>
                <p className="text-sm md:text-base text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Project */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-light mb-4 md:mb-6">Featured Project</h2>
              <p className="text-sm md:text-base text-gray-600 mb-6 md:mb-8">
                The Zen Minimalist Kitchen combines clean lines with natural materials, 
                creating a serene space that balances modern aesthetics with practical functionality.
              </p>
              <Link 
                to="/projects/modern-kitchen"
                className="float-on-hover border-2 border-black text-black px-5 md:px-6 py-2 md:py-3 rounded-full inline-flex items-center space-x-2 hover:bg-black hover:text-white transition text-sm md:text-base"
              >
                <span>View Project</span>
                <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
              </Link>
            </div>
            <div className="relative h-[250px] md:h-[400px] image-3d-container">
              <img 
                src="https://i.postimg.cc/XvXwh1wh/IMG-5999.jpg"
                alt="Zen Minimalist Kitchen"
                className="w-full h-full object-cover rounded-lg image-3d"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-black text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-light mb-4 md:mb-6">Let's Connect</h2>
            <p className="text-sm md:text-base text-gray-400 mb-8">
              Follow us on Instagram for the latest updates and design inspiration.
            </p>
            <a 
              href="https://instagram.com/vainraukh_"
              target="_blank"
              rel="noopener noreferrer"
              className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-6 md:px-8 py-3 md:py-4 rounded-full hover:bg-gray-100 transition"
            >
              <Instagram className="h-5 w-5" />
              <span>@vainraukh_</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 px-4 md:px-6 py-4 md:py-6 transition-all duration-300 ${
      isScrolled ? 'bg-black/80 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link 
          to="/" 
          className="flex items-center space-x-3 z-50 logo-3d"
          onClick={() => setIsMenuOpen(false)}
        >
          <div className="relative w-6 md:w-8 h-6 md:h-8">
            <Square className="h-3 md:h-4 w-3 md:w-4 text-white absolute top-0 left-0 stroke-[1.5]" />
            <Square className="h-3 md:h-4 w-3 md:w-4 text-white absolute top-0 right-0 stroke-[1.5]" />
            <Square className="h-3 md:h-4 w-3 md:w-4 text-white absolute bottom-0 left-0 fill-white stroke-[1.5]" />
            <Square className="h-3 md:h-4 w-3 md:w-4 text-white absolute bottom-0 right-0 stroke-[1.5]" />
          </div>
          <span className="text-white text-lg md:text-xl font-light tracking-wider">NOVADESIGN</span>
        </Link>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-white z-50"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/services" className="text-white hover:text-gray-200 transition">Services</Link>
          <Link to="/projects" className="text-white hover:text-gray-200 transition">Projects</Link>
          <Link to="/about" className="text-white hover:text-gray-200 transition">About</Link>
          <Link to="/contact" className="text-white hover:text-gray-200 transition">Contact</Link>
        </div>

        {/* Mobile Menu */}
        <div className={`fixed inset-0 bg-black/95 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}>
          <div className="flex flex-col items-center justify-center h-full space-y-8">
            <Link 
              to="/services" 
              className="text-white text-2xl hover:text-gray-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </Link>
            <Link 
              to="/projects" 
              className="text-white text-2xl hover:text-gray-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              Projects
            </Link>
            <Link 
              to="/about" 
              className="text-white text-2xl hover:text-gray-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link 
              to="/contact" 
              className="text-white text-2xl hover:text-gray-200 transition"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

function PageTransition({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    setIsTransitioning(true);
    const timer = setTimeout(() => setIsTransitioning(false), 500);
    return () => clearTimeout(timer);
  }, [location]);

  if (isTransitioning) {
    return <LoadingSpinner />;
  }

  return <>{children}</>;
}

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <>
      <Navigation />
      <Suspense fallback={<LoadingSpinner />}>
        <PageTransition>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<Services />} />
            <Route path="/services/visual-architecture" element={<VisualArchitecture />} />
            <Route path="/services/interior-planning" element={<InteriorPlanning />} />
            <Route path="/services/project-management" element={<ProjectManagement />} />
            <Route path="/services/visual-architecture/pricing" element={<Pricing />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/projects/modern-kitchen" element={<ModernKitchenDesign />} />
            <Route path="/projects/bright-timeless" element={<BrightTimelessKitchen />} />
          </Routes>
        </PageTransition>
      </Suspense>
    </>
  );
}

export default App;
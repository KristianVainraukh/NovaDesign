import React from 'react';
import { ArrowLeft, ArrowRight, Check, Compass, Palette, Lightbulb, Ruler, PenTool, Sofa } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: <Compass className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Kitchen Design",
    description: "Creating functional and beautiful kitchens that combine style with practicality.",
    features: [
      "Layout optimization",
      "Cabinet design",
      "Appliance selection",
      "Storage solutions"
    ]
  },
  {
    icon: <Palette className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Bathroom Design",
    description: "Transforming bathrooms into luxurious personal sanctuaries with attention to every detail.",
    features: [
      "Fixture selection",
      "Tile design",
      "Storage planning",
      "Lighting solutions"
    ]
  },
  {
    icon: <Lightbulb className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Living Spaces",
    description: "Designing comfortable and stylish living areas that reflect your lifestyle.",
    features: [
      "Space planning",
      "Furniture layout",
      "Color schemes",
      "Material selection"
    ]
  },
  {
    icon: <Ruler className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Bedrooms",
    description: "Creating peaceful retreats that combine comfort with personal style.",
    features: [
      "Layout optimization",
      "Storage design",
      "Lighting plans",
      "Material selection"
    ]
  },
  {
    icon: <PenTool className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Custom Solutions",
    description: "Tailored design solutions for unique spaces and specific needs.",
    features: [
      "Built-in features",
      "Custom cabinetry",
      "Special storage",
      "Unique layouts"
    ]
  },
  {
    icon: <Sofa className="h-6 w-6 md:h-8 md:w-8" />,
    title: "Material Selection",
    description: "Curating the perfect combination of materials for durability and style.",
    features: [
      "Countertop selection",
      "Cabinet finishes",
      "Flooring options",
      "Hardware choices"
    ]
  }
];

const process = [
  {
    title: "Initial Consultation",
    description: "We begin with a detailed discussion of your vision, needs, and budget. This helps us understand how you use your space and what functionality is most important to you."
  },
  {
    title: "Space Analysis",
    description: "Our team conducts a thorough assessment of your kitchen, bathroom, or living space, taking precise measurements and noting existing features and constraints."
  },
  {
    title: "Design Development",
    description: "We create detailed design concepts including layout plans, material selections, and 3D visualizations to help you envision the final result."
  },
  {
    title: "Design Refinement",
    description: "Based on your feedback, we refine every aspect of the design, from cabinet details to lighting plans, ensuring perfect functionality and style."
  },
  {
    title: "Implementation",
    description: "We coordinate with contractors and suppliers, overseeing the installation to ensure every detail is executed according to plan."
  }
];

function InteriorPlanning() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80"
            alt="Luxury Kitchen Design"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <Link 
            to="/services"
            className="inline-flex items-center space-x-2 text-white hover:text-gray-200 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4 md:h-5 md:w-5" />
            <span>Back to Services</span>
          </Link>
          <h1 className="text-4xl md:text-7xl font-light mb-6">Residential Interior Design</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl">
            Specializing in beautiful, functional kitchens, luxurious bathrooms, and 
            thoughtfully designed living spaces. We create residential interiors that 
            perfectly balance style with practicality.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-16 text-center">Our Services</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-white p-8 rounded-lg shadow-sm hover:shadow-xl transition-shadow"
              >
                <div className="mb-6 text-gray-800">{service.icon}</div>
                <h3 className="text-xl font-medium mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center space-x-2 text-sm text-gray-600">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-16 text-center">Our Process</h2>
          <div className="space-y-12">
            {process.map((step, index) => (
              <div 
                key={index}
                className="flex flex-col md:flex-row gap-8 items-start"
              >
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-black text-white flex items-center justify-center text-xl font-light">
                  {index + 1}
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-4">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-light mb-6">Ready to Transform Your Home?</h2>
          <p className="text-lg md:text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Let's create beautiful, functional spaces that enhance your daily life.
          </p>
          <Link 
            to="/contact"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-8 py-4 rounded-full hover:bg-gray-100 transition"
          >
            <span>Start Your Project</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}

export default InteriorPlanning;
import React from 'react';
import { ArrowRight, Users, Zap, Eye, Target, Droplet } from 'lucide-react';

const teamMembers = [
  {
    name: "Kristian Vainraukh",
    role: "Lead Visualizer",
    image: "https://i.postimg.cc/Y9xHvL4s/unnamed-1.jpg",
    description: "With 5 years of construction experience in both interiors and exteriors, Kristian has worked with major companies that provided extensive design training. Having successfully completed 7 projects, his expertise combines practical construction knowledge with refined design sensibilities."
  }
];

const values = [
  {
    icon: <Zap className="h-5 w-5 md:h-6 md:w-6" />,
    title: "Impact",
    description: "Helping clients envision and communicate their designs effectively, creating meaningful connections through visuals."
  },
  {
    icon: <Droplet className="h-5 w-5 md:h-6 md:w-6" />,
    title: "Clarity",
    description: "Transforming blueprints into compelling visuals that communicate design intent effortlessly."
  },
  {
    icon: <Target className="h-5 w-5 md:h-6 md:w-6" />,
    title: "Precision",
    description: "Meticulous attention to detail ensures excellence in every aspect of our work."
  },
  {
    icon: <Eye className="h-5 w-5 md:h-6 md:w-6" />,
    title: "Vision",
    description: "Helping clients see the future of their projects with stunning 3D renderings."
  }
];

function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&q=80"
            alt="Modern Office"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6">
          <h1 className="text-3xl md:text-7xl font-light mb-3 md:mb-6">Our Story</h1>
          <p className="text-sm md:text-xl text-gray-300 max-w-2xl">
            Driven by innovation and a commitment to excellence, we create architectural 
            visualizations that inspire and transform spaces.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-12 md:py-24">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-6 md:gap-12 items-center">
            <div>
              <h2 className="text-2xl md:text-4xl font-light mb-4 md:mb-6">Our Mission</h2>
              <p className="text-sm md:text-base text-gray-600 mb-4 md:mb-6">
                At NovaDesign, we believe that architectural visualization has the power to bring ideas to life, 
                transforming concepts into immersive, photorealistic experiences. Our mission is to craft high-quality, 
                cutting-edge visuals that inspire, communicate, and elevate architectural design.
              </p>
              <p className="text-sm md:text-base text-gray-600">
                Through a combination of artistic vision, technical precision, and collaboration with our clients, 
                we push the boundaries of 3D rendering to deliver compelling, detail-rich imagery. Committed to 
                innovation and excellence, we create visuals that effectively showcase architectural designs with 
                clarity and impact.
              </p>
            </div>
            <div className="relative h-[250px] md:h-[400px] rounded-lg overflow-hidden">
              <img 
                src="https://blog.twinbru.com/hubfs/01_Twinbru_Article_Archviz%20Explained%20-%20A%20Comprehensive%20Guide_Apr2024_Image0.jpg"
                alt="Architectural Visualization"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-12 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <h2 className="text-2xl md:text-4xl font-light mb-8 md:mb-16 text-center">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
            {values.map((value, index) => (
              <div 
                key={index}
                className="bg-white p-5 md:p-8 rounded-lg shadow-sm hover:shadow-md transition"
              >
                <div className="mb-3 md:mb-4 text-gray-800">{value.icon}</div>
                <h3 className="text-lg md:text-xl font-medium mb-2 md:mb-4">{value.title}</h3>
                <p className="text-sm md:text-base text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-12 md:py-24">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <h2 className="text-2xl md:text-4xl font-light mb-8 md:mb-16 text-center">Our Team</h2>
          <div className="max-w-lg mx-auto">
            {teamMembers.map((member, index) => (
              <div 
                key={index}
                className="group"
              >
                <div className="relative mb-4 md:mb-6 overflow-hidden rounded-lg aspect-[3/4]">
                  <img 
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <h3 className="text-lg md:text-xl font-medium mb-1 md:mb-2">{member.name}</h3>
                <p className="text-sm md:text-base text-gray-500 mb-2 md:mb-4">{member.role}</p>
                <p className="text-sm md:text-base text-gray-600">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 md:px-6 text-center">
          <h2 className="text-2xl md:text-4xl font-light mb-3 md:mb-6">Start Your Project</h2>
          <p className="text-sm md:text-xl text-gray-400 mb-6 md:mb-8 max-w-2xl mx-auto">
            Let's create something extraordinary together.
          </p>
          <a 
            href="mailto:Novadesignnarch@gmail.com"
            className="float-on-hover inline-flex items-center justify-center space-x-2 bg-white text-black px-6 md:px-8 py-3 md:py-4 rounded-full hover:bg-gray-100 transition text-sm md:text-base"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
          </a>
        </div>
      </section>
    </div>
  );
}

export default About;
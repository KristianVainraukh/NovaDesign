import React from 'react';
import { ArrowLeft, ArrowRight, Check, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';

const projects = [
  {
    title: "Zen Minimalist Kitchen",
    description: "A modern kitchen design emphasizing clean lines and natural materials.",
    image: "https://i.postimg.cc/XvXwh1wh/IMG-5999.jpg",
    link: "/projects/modern-kitchen"
  },
  {
    title: "Bright & Timeless Kitchen",
    description: "A luminous kitchen design blending classic elements with contemporary touches.",
    image: "https://i.postimg.cc/rwjSS7fp/Untitled-11-1.jpg",
    link: "/projects/bright-timeless"
  }
];

function VisualArchitecture() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-24 md:py-32 bg-black text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://i.postimg.cc/w38Tz1WB/sdp-001.jpg"
            alt="Interior Architecture Visualization"
            className="w-full h-full object-cover opacity-50"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <Link 
            to="/services"
            className="inline-flex items-center space-x-2 text-white hover:text-gray-200 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4 md:h-5 md:w-5" />
            <span>Back to Services</span>
          </Link>
          <h1 className="text-4xl md:text-7xl font-light mb-6">Visual Architecture</h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl">
            Transform your architectural vision into stunning reality with our comprehensive 
            visual design services. We combine artistic creativity with technical expertise 
            to create immersive architectural experiences.
          </p>
        </div>
      </section>

      {/* Pricing Factors Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-12">Understanding Our Pricing</h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-medium mb-6">Key Pricing Factors</h3>
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">Quality Level – Basic, photorealistic, or ultra-high-end</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">Revisions – Number of revisions included</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">Turnaround Time – Standard vs. rush delivery</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">Project Complexity – Large open spaces vs. detailed, custom furniture</span>
                </li>
                <li className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">Location & Market Rates – Your region and client budget</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-medium mb-6">General Price Range (Per Render)</h3>
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h4 className="font-medium mb-2">Basic Rendering</h4>
                  <p className="text-2xl font-light text-gray-900">$150 - $300</p>
                  <p className="text-sm text-gray-600 mt-2">per image</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h4 className="font-medium mb-2">Photorealistic Rendering</h4>
                  <p className="text-2xl font-light text-gray-900">$300 - $800</p>
                  <p className="text-sm text-gray-600 mt-2">per image</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h4 className="font-medium mb-2">High-End/Ultra-Realistic Rendering</h4>
                  <p className="text-2xl font-light text-gray-900">$800 - $2,000</p>
                  <p className="text-sm text-gray-600 mt-2">per image</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-16 text-center">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                question: "What's included in each visualization?",
                answer: "Each visualization includes high-quality renders from multiple angles, material specifications, and lighting setups. The number of views and revisions varies by plan."
              },
              {
                question: "Can I customize a package?",
                answer: "Yes! We can create custom packages tailored to your specific project needs. Contact us to discuss your requirements."
              },
              {
                question: "What format will I receive the files in?",
                answer: "You'll receive high-resolution JPEG/PNG files for still renders, and interactive web-based formats for virtual tours where applicable."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-white p-8 rounded-lg">
                <h3 className="text-xl font-medium mb-4">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-light mb-16">Featured Projects</h2>
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            {projects.map((project, index) => (
              <Link 
                key={index}
                to={project.link}
                className="group relative overflow-hidden rounded-lg aspect-[4/3]"
              >
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="text-xl md:text-2xl font-medium mb-2">{project.title}</h3>
                    <p className="text-sm md:text-base text-gray-200">{project.description}</p>
                    <div className="mt-4 inline-flex items-center space-x-2 text-sm md:text-base">
                      <span>View Project</span>
                      <ArrowRight className="h-4 w-4 md:h-5 md:w-5" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-light mb-6">Ready to Start Your Project?</h2>
          <p className="text-lg md:text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Let's discuss your visualization needs and find the perfect package for your project.
          </p>
          <Link 
            to="/contact"
            className="float-on-hover inline-flex items-center space-x-2 bg-white text-black px-8 py-4 rounded-full hover:bg-gray-100 transition"
          >
            <span>Contact Us</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}

export default VisualArchitecture;
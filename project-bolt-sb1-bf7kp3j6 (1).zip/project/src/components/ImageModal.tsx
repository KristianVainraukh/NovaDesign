import React from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface ImageModalProps {
  images: { image: string; description: string }[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNext: () => void;
  onPrevious: () => void;
}

function ImageModal({ images, currentIndex, isOpen, onClose, onNext, onPrevious }: ImageModalProps) {
  if (!isOpen) return null;

  const currentImage = images[currentIndex];

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center">
      {/* Close button */}
      <button 
        onClick={onClose}
        className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
      >
        <X className="h-6 w-6 md:h-8 md:w-8" />
      </button>

      {/* Navigation buttons */}
      <button 
        onClick={onPrevious}
        className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
        disabled={currentIndex === 0}
      >
        <ChevronLeft className="h-6 w-6 md:h-8 md:w-8" />
      </button>
      <button 
        onClick={onNext}
        className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
        disabled={currentIndex === images.length - 1}
      >
        <ChevronRight className="h-6 w-6 md:h-8 md:w-8" />
      </button>

      {/* Image container */}
      <div className="max-w-[90vw] max-h-[90vh] px-4 md:px-0">
        <img 
          src={currentImage.image}
          alt={currentImage.description}
          className="max-w-full max-h-[80vh] object-contain"
        />
        <p className="text-white text-center mt-4 text-sm md:text-base px-8">{currentImage.description}</p>
      </div>
    </div>
  );
}

export default ImageModal;
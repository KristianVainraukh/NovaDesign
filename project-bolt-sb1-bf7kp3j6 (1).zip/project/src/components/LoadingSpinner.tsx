import React from 'react';
import { Square } from 'lucide-react';

function LoadingSpinner() {
  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="text-center">
        <div className="w-12 h-12 md:w-16 md:h-16 mb-6 md:mb-8 loading-logo mx-auto">
          <div className="relative w-6 h-6 md:w-8 md:h-8 mx-auto">
            <Square className="h-3 w-3 md:h-4 md:w-4 text-white absolute top-0 left-0 stroke-[1.5]" />
            <Square className="h-3 w-3 md:h-4 md:w-4 text-white absolute top-0 right-0 stroke-[1.5]" />
            <Square className="h-3 w-3 md:h-4 md:w-4 text-white absolute bottom-0 left-0 fill-white stroke-[1.5]" />
            <Square className="h-3 w-3 md:h-4 md:w-4 text-white absolute bottom-0 right-0 stroke-[1.5]" />
          </div>
        </div>
        <p className="text-white text-lg md:text-xl font-light">Loading...</p>
      </div>
    </div>
  );
}

export default LoadingSpinner;